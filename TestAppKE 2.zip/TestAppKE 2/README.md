# TestAppKE

A modern iOS application built with SwiftUI following the MVVM (Model-View-ViewModel) architecture pattern. This app showcases a car listing and details interface with a clean, modern design.

## Features

- 🚗 Car listing with detailed information
- 📱 Modern SwiftUI interface
- 🔄 Asynchronous data loading
- 🎨 Custom UI components
- 🌐 Web view integration
- 📱 Responsive design

## Architecture

The project follows the MVVM (Model-View-ViewModel) architecture pattern:

```
TestAppKE/
├── Models/          # Data models
├── Views/           # SwiftUI views
├── ViewModels/      # View models for business logic
├── Services/        # Data and network services
└── Utilities/       # Helper components and styles
```

### Key Components

- **Models**: Data structures and business objects
- **Views**: SwiftUI views for the user interface
- **ViewModels**: Business logic and state management
- **Services**: Data fetching and processing
- **Utilities**: Reusable components and styles

## Requirements

- iOS 15.0+
- Xcode 13.0+
- Swift 5.5+

## Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/TestAppKE.git
```

2. Open the project in Xcode
```bash
cd TestAppKE
open TestAppKE.xcodeproj
```

3. Build and run the project

## Project Structure

### Models
- `Car.swift`: Car data model

### Views
- `MainView.swift`: Main application view
- `CarListView.swift`: List of cars
- `CarDetailView.swift`: Detailed car information
- `CarCard.swift`: Car card component
- `WebViewScreen.swift`: Web view integration
- `SplashScreen.swift`: Application splash screen

### ViewModels
- `CarListViewModel.swift`: Manages car list state and logic
- `CarDetailViewModel.swift`: Handles car detail view logic
- `WebViewViewModel.swift`: Manages web view state

### Services
- `CarService.swift`: Handles car data operations

### Utilities
- `ModernButtonStyle.swift`: Custom button styling
- `SpecificationItem.swift`: Reusable specification component

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- SwiftUI for the modern UI framework
- MVVM architecture pattern
- All contributors and maintainers 