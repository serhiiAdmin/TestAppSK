
import Foundation

struct Car: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let imageUrl: String
    let price: String
    let detailedDescription: String
    let specifications: [String: String]
}
