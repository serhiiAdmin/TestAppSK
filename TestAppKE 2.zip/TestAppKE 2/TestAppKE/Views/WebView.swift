
import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    @ObservedObject var webViewModel: WebViewModel
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.navigationDelegate = context.coordinator
        webViewModel.webView = webView
        
        if let url = URL(string: "https://onlywinapp.space/CgnV6V99") {
            var request = URLRequest(url: url)
            request.setValue("CA", forHTTPHeaderField: "X-Country-Code")
            request.setValue("Canada", forHTTPHeaderField: "X-Country")
            webView.load(request)
        }
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.webViewModel.canGoBack = webView.canGoBack
            parent.webViewModel.canGoForward = webView.canGoForward
        }
    }
}

