
import SwiftUI

struct CarDetailView: View {
    let car: Car
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
            
                ZStack(alignment: .bottom) {
                    Image(car.imageUrl)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 300)
                        .frame(maxWidth: .infinity)
                        .clipped()
                    
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.black.opacity(0.7),
                            Color.black.opacity(0.3),
                            Color.clear
                        ]),
                        startPoint: .bottom,
                        endPoint: .top
                    )
                    
                    HStack {
                        Spacer()
                        Text(car.price)
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(Color.blue)
                            .cornerRadius(25)
                            .padding(.bottom, 20)
                            .padding(.leading, 20)
                    }
                    .padding(.trailing, 10)
                }
              
                VStack(alignment: .leading, spacing: 24) {
                  
                    VStack(alignment: .leading, spacing: 12) {
                        Text(car.name)
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.primary)
                        
                        Text(car.detailedDescription)
                            .font(.body)
                            .foregroundColor(.gray)
                            .lineSpacing(4)
                    }
                    
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Specifications")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        VStack(spacing: 12) {
                            ForEach(Array(car.specifications.keys.sorted()), id: \.self) { key in
                                SpecificationRow(key: key, value: car.specifications[key] ?? "")
                            }
                        }
                        .padding(.top, 8)
                    }
                }
                .padding(20)
                .background(Color.white)
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    dismiss()
                }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.blue)
                }
            }
        }
    }
}
