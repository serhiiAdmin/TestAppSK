
import SwiftUI
import AVFoundation
import NetworkExtension

struct MainView: View {
    var body: some View {
        NavigationView {
                ZStack {
                    Image("MainBack")
                        .resizable()
                        .ignoresSafeArea(.all)
                    LinearGradient(
                        gradient: Gradient(colors: [Color.black.opacity(0.5), Color.black]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea()
                   
                    VStack {
                        Spacer()
                        HStack(spacing: 20) {
                            NavigationLink(destination: WebViewScreen()) {
                                VStack(spacing: 15) {
                                    Image(systemName: "globe")
                                        .font(.system(size: 36, weight: .medium))
                                        .foregroundStyle(
                                            LinearGradient(
                                                colors: [.white, .white.opacity(0.8)],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                    Text("WebView")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                }
                                .frame(maxWidth: .infinity)
                                .frame(height: 160)
                                .background(
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25)
                                            .fill(
                                                LinearGradient(
                                                    colors: [
                                                        Color.white.opacity(0.2),
                                                        Color.white.opacity(0.1)
                                                    ],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                )
                                            )
                                        
                                        RoundedRectangle(cornerRadius: 25)
                                            .stroke(
                                                LinearGradient(
                                                    colors: [
                                                        .white.opacity(0.5),
                                                        .white.opacity(0.2)
                                                    ],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: 1
                                            )
                                    }
                                )
                                .shadow(color: Color.white.opacity(0.2), radius: 20, x: 0, y: 10)
                            }
                            .buttonStyle(ModernButtonStyle())
                            
                            NavigationLink(destination: CarListView()) {
                                VStack(spacing: 15) {
                                    Image(systemName: "car.fill")
                                        .font(.system(size: 36, weight: .medium))
                                        .foregroundStyle(
                                            LinearGradient(
                                                colors: [.white, .white.opacity(0.8)],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                    Text("Car List")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                }
                                .frame(maxWidth: .infinity)
                                .frame(height: 160)
                                .background(
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25)
                                            .fill(
                                                LinearGradient(
                                                    colors: [
                                                        Color.white.opacity(0.2),
                                                        Color.white.opacity(0.1)
                                                    ],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                )
                                            )
                                        
                                        RoundedRectangle(cornerRadius: 25)
                                            .stroke(
                                                LinearGradient(
                                                    colors: [
                                                        .white.opacity(0.5),
                                                        .white.opacity(0.2)
                                                    ],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: 1
                                            )
                                    }
                                )
                                .shadow(color: Color.white.opacity(0.2), radius: 20, x: 0, y: 10)
                            }
                            .buttonStyle(ModernButtonStyle())
                        }
                        .padding(.horizontal, 25)
                    }
                    .padding(.bottom, 110)
            }
        }
    }

    private func openVPNSettings() {
        let vpnUrls = [
            "App-Prefs:root=General&path=VPN",
            "prefs:root=General&path=VPN",
            "App-Prefs:root=VPN",
            "Prefs:root=VPN"
        ]
        
        for urlString in vpnUrls {
            if let url = URL(string: urlString), UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                return
            }
        }
    }
}


