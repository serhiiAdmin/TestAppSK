
import SwiftUI

struct CarListView: View {
    let cars = [
        Car(
            name: "Tesla Model 3",
            description: "Electric sedan with impressive range",
            imageUrl: "tesla3",
            price: "$35,000",
            detailedDescription: "The Tesla Model 3 is an electric four-door sedan developed by Tesla. The Model 3 Standard Range Plus version delivers an EPA-rated all-electric range of 263 miles (423 km) and the Long Range versions deliver 353 miles (568 km).",
            specifications: [
                "Range": "263-353 miles",
                "0-60 mph": "3.1-5.3 seconds",
                "Top Speed": "140-162 mph",
                "Power": "283-450 hp"
            ]
        ),
        Car(
            name: "BMW M3",
            description: "High-performance luxury sports car",
            imageUrl: "bmwM3",
            price: "$69,900",
            detailedDescription: "The BMW M3 is a high-performance version of the BMW 3 Series, developed by BMW's in-house motorsport division, BMW M GmbH. It has been produced in six generations since 1986.",
            specifications: [
                "Engine": "3.0L TwinPower Turbo",
                "Power": "473 hp",
                "0-60 mph": "3.8 seconds",
                "Top Speed": "180 mph"
            ]
        ),
        Car(
            name: "Mercedes-Benz S-Class",
            description: "Luxury flagship sedan",
            imageUrl: "mersedes",
            price: "$111,100",
            detailedDescription: "The Mercedes-Benz S-Class is a series of full-size luxury sedans and limousines produced by the German automaker Mercedes-Benz. The S-Class is the flagship vehicle for Mercedes-Benz and has been one of the world's best-selling luxury sedans.",
            specifications: [
                "Engine": "3.0L I6 Hybrid",
                "Power": "429 hp",
                "0-60 mph": "4.4 seconds",
                "Range": "600 miles"
            ]
        ),
        Car(
            name: "Audi RS7",
            description: "Sportback with incredible performance",
            imageUrl: "audi",
            price: "$118,500",
            detailedDescription: "The Audi RS7 is a high-performance luxury sportback produced by Audi Sport GmbH. It combines the practicality of a four-door coupe with the performance of a supercar.",
            specifications: [
                "Engine": "4.0L V8 Twin-Turbo",
                "Power": "591 hp",
                "0-60 mph": "3.5 seconds",
                "Top Speed": "190 mph"
            ]
        ),
        Car(
            name: "Porsche 911",
            description: "Iconic sports car",
            imageUrl: "porshe911",
            price: "$106,100",
            detailedDescription: "The Porsche 911 is a two-door, 2+2 high performance rear-engined sports car introduced in September 1964 by Porsche AG of Stuttgart, Germany. It has a rear-mounted flat-six engine and all round independent suspension.",
            specifications: [
                "Engine": "3.0L Twin-Turbo Flat-6",
                "Power": "443 hp",
                "0-60 mph": "3.2 seconds",
                "Top Speed": "190 mph"
            ]
        )
    ]
    
    var body: some View {
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(cars) { car in
                        NavigationLink(destination: CarDetailView(car: car)) {
                            CarCard(car: car)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Top Cars")
    }
}


