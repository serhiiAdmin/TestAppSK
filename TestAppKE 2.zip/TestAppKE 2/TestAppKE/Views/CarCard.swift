
import SwiftUI

struct CarCard: View {
    let car: Car
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
           
            ZStack(alignment: .bottom) {
                Image(car.imageUrl)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 220)
                    .frame(maxWidth: .infinity)
                    .clipped()
               
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.black.opacity(0.7),
                        Color.black.opacity(0.3),
                        Color.clear
                    ]),
                    startPoint: .bottom,
                    endPoint: .top
                )
                
                HStack {
                    Spacer()
                    Text(car.price)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.blue)
                        .cornerRadius(20)
                        .padding(.bottom, 16)
                        .padding(.leading, 16)
                }
                .padding(.trailing, 10)
            }
           
            VStack(alignment: .leading, spacing: 8) {
                Text(car.name)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text(car.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(2)
                
                HStack(spacing: 16) {
                    if let acceleration = car.specifications["0-60 mph"] {
                        SpecificationItem(icon: "speedometer", text: "0-60: \(acceleration)")
                    }
                    if let power = car.specifications["Power"] {
                        SpecificationItem(icon: "gauge", text: power)
                    }
                    if let engine = car.specifications["Engine"] {
                        SpecificationItem(icon: "fuelpump", text: engine)
                    }
                }
                .padding(.top, 4)
            }
            .padding(16)
            .background(Color.white)
        }
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
        .padding(.horizontal)
    }
}

