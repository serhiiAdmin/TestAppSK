import Foundation

protocol CarServiceProtocol {
    func fetchCars() async throws -> [Car]
    func fetchCarDetails(carId: UUID) async throws -> Car
}

class CarService: CarServiceProtocol {
    func fetchCars() async throws -> [Car] {
        return []
    }
    
    func fetchCarDetails(carId: UUID) async throws -> Car {
        throw NSError(domain: "CarService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Not implemented"])
    }
}
