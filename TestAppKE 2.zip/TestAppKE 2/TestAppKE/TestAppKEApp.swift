

import SwiftUI

@main
struct TestAppKEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
