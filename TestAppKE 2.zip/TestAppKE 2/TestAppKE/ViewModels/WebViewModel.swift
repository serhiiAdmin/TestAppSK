
import SwiftUI
import WebKit

class WebViewModel: ObservableObject {
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    weak var webView: WKWebView?
    
    func goBack() {
        webView?.goBack()
    }
    
    func goForward() {
        webView?.goForward()
    }
    
    func reload() {
        webView?.reload()
    }
    
    func loadURL(_ urlString: String) {
        var urlToLoad = urlString
        if !urlString.hasPrefix("http://") && !urlString.hasPrefix("https://") {
            urlToLoad = "https://" + urlString
        }
        
        if let url = URL(string: urlToLoad) {
            var request = URLRequest(url: url)
            request.setValue("CA", forHTTPHeaderField: "X-Country-Code")
            request.setValue("Canada", forHTTPHeaderField: "X-Country")
            webView?.load(request)
        }
    }
}
