import Foundation
import SwiftUI

class CarDetailViewModel: ObservableObject {
    @Published var car: Car?
    @Published var isLoading = false
    @Published var error: Error?
    
    func loadCarDetails(carId: UUID) {
        isLoading = true
        isLoading = false
    }
    
    func refreshCarDetails() {
        if let carId = car?.id {
            loadCarDetails(carId: carId)
        }
    }
} 
