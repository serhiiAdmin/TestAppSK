import Foundation
import SwiftUI
import WebKit

class WebViewViewModel: ObservableObject {
    @Published var url: URL?
    @Published var isLoading = false
    @Published var error: Error?
    
    func loadURL(_ urlString: String) {
        if let url = URL(string: urlString) {
            self.url = url
        }
    }
    
    func refresh() {
        if let currentURL = url {
            loadURL(currentURL.absoluteString)
        }
    }
} 