import Foundation
import SwiftUI

class CarListViewModel: ObservableObject {
    @Published var cars: [Car] = []
    @Published var isLoading = false
    @Published var error: Error?
    
    func fetchCars() {
        isLoading = true
        isLoading = false
    }
    
    func refreshCars() {
        fetchCars()
    }
} 
